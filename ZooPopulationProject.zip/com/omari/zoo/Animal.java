package com.omari.zoo;



public class Animal {
    static int numOfAnimals = 0;

    private String sex;
    private int age;
    private int weight;
    private String animalName;
    private String animalID;
    private String animalBirthDate;
    private String animalColor;
    private String animalOrigin;
    private String animalArrivalDate;

    public Animal() {
        numOfAnimals++;
    }

    public Animal(String sex, int age, int weight, String animalName, String animalID,
                  String animalBirthDate, String animalColor, String animalOrigin,
                  String animalArrivalDate) {
        numOfAnimals++;
        this.sex = sex;
        this.age = age;
        this.weight = weight;
        this.animalName = animalName;
        this.animalID = animalID;
        this.animalBirthDate = animalBirthDate;
        this.animalColor = animalColor;
        this.animalOrigin = animalOrigin;
        this.animalArrivalDate = animalArrivalDate;
    }

    // Getters
    public String getSex() { return sex; }
    public int getAge() { return age; }
    public int getWeight() { return weight; }
    public String getAnimalName() { return animalName; }
    public String getAnimalID() { return animalID; }
    public String getAnimalBirthDate() { return animalBirthDate; }
    public String getAnimalColor() { return animalColor; }
    public String getAnimalOrigin() { return animalOrigin; }
    public String getAnimalArrivalDate() { return animalArrivalDate; }

    // Setters
    public void setSex(String sex) { this.sex = sex; }
    public void setAge(int age) { this.age = age; }
    public void setWeight(int weight) { this.weight = weight; }
    public void setAnimalName(String name) { this.animalName = name; }
    public void setAnimalID(String id) { this.animalID = id; }
    public void setAnimalBirthDate(String birthDate) { this.animalBirthDate = birthDate; }
    public void setAnimalColor(String color) { this.animalColor = color; }
    public void setAnimalOrigin(String origin) { this.animalOrigin = origin; }
    public void setAnimalArrivalDate(String arrivalDate) { this.animalArrivalDate = arrivalDate; }
}
