package com.omari.zoo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class App {

    public static void main(String[] args) {
        System.out.println("Welcome to the Zoo Program!");

        // Load animal names
        String filePath = "animalNames.txt";
        AnimalNameListsWrapper animalLists = Utilities.createAnimalNameLists(filePath);

        ArrayList<String> hyenaNames = animalLists.getHyenaNameList();
        ArrayList<String> lionNames = animalLists.getLionNameList();
        ArrayList<String> tigerNames = animalLists.getTigerNameList();
        ArrayList<String> bearNames = animalLists.getBearNameList();

        // Lists to store animals
        ArrayList<Hyena> hyenaList = new ArrayList<>();
        ArrayList<Lion> lionList = new ArrayList<>();
        ArrayList<Tiger> tigerList = new ArrayList<>();
        ArrayList<Bear> bearList = new ArrayList<>();

        // HashMap to store all animals by ID
        HashMap<String, Animal> zooAnimals = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("arrivingAnimals.txt"))) {
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                // --- Split by commas ---
                String[] parts = line.split(",\\s*");
                if (parts.length < 5) continue;

                // --- Parse first part: age, sex, species ---
                String[] firstPart = parts[0].split(" ");
                int age = Integer.parseInt(firstPart[0]);
                String sex = firstPart[3];
                String species = firstPart[4].toLowerCase();

                // --- Parse second part: birth season ---
                String birthSeason = "unknown";
                if (parts[1].toLowerCase().contains("born in")) {
                    String[] secondPart = parts[1].split(" ");
                    if (secondPart.length >= 3) birthSeason = secondPart[2];
                }

                // --- Parse color, weight, origin ---
                String color = parts[2];
                int weight = Integer.parseInt(parts[3].split(" ")[0]);
                String origin = parts[4];
                if (parts.length > 5) origin += ", " + parts[5];

                // Arrival date
                String arrivalDate = Utilities.arrivalDate();

                // Birthday
                String birthDate = Utilities.calcAnimalBirthDate(age, birthSeason);

                // Generate unique ID
                String id = Utilities.calcAnimalID(species);

                // Assign name
                String nameAssigned = "NoName";
                Animal animal = null;

                switch (species) {
                    case "hyena":
                        if (!hyenaNames.isEmpty()) nameAssigned = hyenaNames.remove(0);
                        animal = new Hyena(sex, age, weight, nameAssigned, id, birthDate, color, origin, arrivalDate);
                        hyenaList.add((Hyena) animal);
                        break;
                    case "lion":
                        if (!lionNames.isEmpty()) nameAssigned = lionNames.remove(0);
                        animal = new Lion(sex, age, weight, nameAssigned, id, birthDate, color, origin, arrivalDate);
                        lionList.add((Lion) animal);
                        break;
                    case "tiger":
                        if (!tigerNames.isEmpty()) nameAssigned = tigerNames.remove(0);
                        animal = new Tiger(sex, age, weight, nameAssigned, id, birthDate, color, origin, arrivalDate);
                        tigerList.add((Tiger) animal);
                        break;
                    case "bear":
                        if (!bearNames.isEmpty()) nameAssigned = bearNames.remove(0);
                        animal = new Bear(sex, age, weight, nameAssigned, id, birthDate, color, origin, arrivalDate);
                        bearList.add((Bear) animal);
                        break;
                    default:
                        System.out.println("Unknown species: " + species);
                        continue;
                }

                // Add to HashMap
                if (animal != null) zooAnimals.put(id, animal);

                // Print info to console
                System.out.println(animal.getAnimalID() + "; " + animal.getAnimalName() +
                        "; birth date: " + animal.getAnimalBirthDate() +
                        "; " + animal.getAnimalColor() +
                        "; " + animal.getSex() +
                        "; " + animal.getWeight() + " pounds; " +
                        animal.getAnimalOrigin() + "; arrived " +
                        animal.getAnimalArrivalDate());
            }

            // Write zooPopulation.txt
            writeZooPopulation("zooPopulation.txt", hyenaList, lionList, tigerList, bearList);

            // Summary
            System.out.println("\nTotal animals: " + zooAnimals.size());
            System.out.println("All IDs: " + zooAnimals.keySet());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeZooPopulation(String fileName,
                                           ArrayList<Hyena> hyenaList,
                                           ArrayList<Lion> lionList,
                                           ArrayList<Tiger> tigerList,
                                           ArrayList<Bear> bearList) {
        try (FileWriter writer = new FileWriter(fileName)) {

            writer.write("Hyena Habitat:\n");
            for (Hyena h : hyenaList) {
                writer.write(h.getAnimalID() + "; " + h.getAnimalName() +
                        "; birth date: " + h.getAnimalBirthDate() +
                        "; " + h.getAnimalColor() +
                        "; " + h.getSex() +
                        "; " + h.getWeight() + " pounds; " +
                        h.getAnimalOrigin() + "; arrived " +
                        h.getAnimalArrivalDate() + "\n");
            }

            writer.write("\nLion Habitat:\n");
            for (Lion l : lionList) {
                writer.write(l.getAnimalID() + "; " + l.getAnimalName() +
                        "; birth date: " + l.getAnimalBirthDate() +
                        "; " + l.getAnimalColor() +
                        "; " + l.getSex() +
                        "; " + l.getWeight() + " pounds; " +
                        l.getAnimalOrigin() + "; arrived " +
                        l.getAnimalArrivalDate() + "\n");
            }

            writer.write("\nTiger Habitat:\n");
            for (Tiger t : tigerList) {
                writer.write(t.getAnimalID() + "; " + t.getAnimalName() +
                        "; birth date: " + t.getAnimalBirthDate() +
                        "; " + t.getAnimalColor() +
                        "; " + t.getSex() +
                        "; " + t.getWeight() + " pounds; " +
                        t.getAnimalOrigin() + "; arrived " +
                        t.getAnimalArrivalDate() + "\n");
            }

            writer.write("\nBear Habitat:\n");
            for (Bear b : bearList) {
                writer.write(b.getAnimalID() + "; " + b.getAnimalName() +
                        "; birth date: " + b.getAnimalBirthDate() +
                        "; " + b.getAnimalColor() +
                        "; " + b.getSex() +
                        "; " + b.getWeight() + " pounds; " +
                        b.getAnimalOrigin() + "; arrived " +
                        b.getAnimalArrivalDate() + "\n");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}