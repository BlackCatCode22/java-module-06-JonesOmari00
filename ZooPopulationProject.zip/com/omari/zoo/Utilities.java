package com.omari.zoo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Utilities {

    public static String calcAnimalID(String species) {
        String id = "";
        switch (species.toLowerCase()) {
            case "hyena":
                id = String.format("Hy%02d", Hyena.numOfHyenas + 1);
                break;
            case "lion":
                id = String.format("Li%02d", Lion.numOfLions + 1);
                break;
            case "tiger":
                id = String.format("Ti%02d", Tiger.numOfTigers + 1);
                break;
            case "bear":
                id = String.format("Be%02d", Bear.numOfBears + 1);
                break;
        }
        return id;
    }

    public static String arrivalDate() {
        Date today = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return formatter.format(today);
    }

    public static String calcAnimalBirthDate(int age, String season) {
        Date today = new Date();
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        int currentYear = Integer.parseInt(yearFormat.format(today));
        int birthYear = currentYear - age;

        season = season.toLowerCase();
        switch (season) {
            case "spring": return birthYear + "-03-21";
            case "summer": return birthYear + "-06-21";
            case "fall":   return birthYear + "-09-21";
            case "winter": return birthYear + "-12-21";
            default:       return birthYear + "-01-01";
        }
    }

    public static AnimalNameListsWrapper createAnimalNameLists(String filePath) {
        ArrayList<String> hyenaList = new ArrayList<>();
        ArrayList<String> lionList = new ArrayList<>();
        ArrayList<String> tigerList = new ArrayList<>();
        ArrayList<String> bearList = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            ArrayList<String> currentList = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();
                switch (line) {
                    case "Hyena Names:": currentList = hyenaList; break;
                    case "Lion Names:": currentList = lionList; break;
                    case "Tiger Names:": currentList = tigerList; break;
                    case "Bear Names:": currentList = bearList; break;
                    default:
                        if (!line.isEmpty() && currentList != null) {
                            String[] names = line.split(",\\s*");
                            for (String name : names) currentList.add(name);
                        }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading names file: " + e.getMessage());
        }

        return new AnimalNameListsWrapper(hyenaList, lionList, tigerList, bearList);
    }
}
